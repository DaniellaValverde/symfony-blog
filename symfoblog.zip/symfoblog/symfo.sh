#!/bin/bash

mysql -u $1 -p coding < symfoblog/coding.sql

php symfosource/bin/console server:start

