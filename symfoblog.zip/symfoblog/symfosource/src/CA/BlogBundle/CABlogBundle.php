<?php

namespace CA\BlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CABlogBundle extends Bundle
{
}
