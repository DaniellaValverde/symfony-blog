<?php

/* @Twig/images/icon-plus-square.svg */
class __TwigTemplate_e7deb82e04b5a5d2567331c5f4d8838c6106fe62c284fabe1c9556215c8f8368 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b10f0f8d8e9bbb9d523357c8809aaf7cf442b7521913a88722bcf46843f67bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b10f0f8d8e9bbb9d523357c8809aaf7cf442b7521913a88722bcf46843f67bd->enter($__internal_1b10f0f8d8e9bbb9d523357c8809aaf7cf442b7521913a88722bcf46843f67bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        $__internal_af550761ef70664063570b9a71c954a4c113cdaef57d357a35b192c4c6c3b550 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af550761ef70664063570b9a71c954a4c113cdaef57d357a35b192c4c6c3b550->enter($__internal_af550761ef70664063570b9a71c954a4c113cdaef57d357a35b192c4c6c3b550_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
";
        
        $__internal_1b10f0f8d8e9bbb9d523357c8809aaf7cf442b7521913a88722bcf46843f67bd->leave($__internal_1b10f0f8d8e9bbb9d523357c8809aaf7cf442b7521913a88722bcf46843f67bd_prof);

        
        $__internal_af550761ef70664063570b9a71c954a4c113cdaef57d357a35b192c4c6c3b550->leave($__internal_af550761ef70664063570b9a71c954a4c113cdaef57d357a35b192c4c6c3b550_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-plus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
", "@Twig/images/icon-plus-square.svg", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-plus-square.svg");
    }
}
