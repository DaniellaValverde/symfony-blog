<?php

/* post/new.html.twig */
class __TwigTemplate_4ce4e4d2c724dbb271685bce1ff503dcc960b15dc062d487db7ac1c449ddef34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "post/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db9216a9fcf1595a8c588b28cac27352f7700e932a775cdbe857738eab9ca46b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db9216a9fcf1595a8c588b28cac27352f7700e932a775cdbe857738eab9ca46b->enter($__internal_db9216a9fcf1595a8c588b28cac27352f7700e932a775cdbe857738eab9ca46b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/new.html.twig"));

        $__internal_5910d3bc745ff8684fa7d97eb7366571f597b3caec22cbae2687b16ec9fe9f79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5910d3bc745ff8684fa7d97eb7366571f597b3caec22cbae2687b16ec9fe9f79->enter($__internal_5910d3bc745ff8684fa7d97eb7366571f597b3caec22cbae2687b16ec9fe9f79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_db9216a9fcf1595a8c588b28cac27352f7700e932a775cdbe857738eab9ca46b->leave($__internal_db9216a9fcf1595a8c588b28cac27352f7700e932a775cdbe857738eab9ca46b_prof);

        
        $__internal_5910d3bc745ff8684fa7d97eb7366571f597b3caec22cbae2687b16ec9fe9f79->leave($__internal_5910d3bc745ff8684fa7d97eb7366571f597b3caec22cbae2687b16ec9fe9f79_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1b44f3fa8efba05713cf6aab3a8c515ae0298a41b68dc4e8b0b81f0521324909 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b44f3fa8efba05713cf6aab3a8c515ae0298a41b68dc4e8b0b81f0521324909->enter($__internal_1b44f3fa8efba05713cf6aab3a8c515ae0298a41b68dc4e8b0b81f0521324909_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_38fec5e1fe9a52f6fc84b9e953a8dddcb0a337c105ff80156412ea22185c12b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38fec5e1fe9a52f6fc84b9e953a8dddcb0a337c105ff80156412ea22185c12b6->enter($__internal_38fec5e1fe9a52f6fc84b9e953a8dddcb0a337c105ff80156412ea22185c12b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Post creation</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 6, $this->getSourceContext()); })()), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 7, $this->getSourceContext()); })()), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 9, $this->getSourceContext()); })()), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_38fec5e1fe9a52f6fc84b9e953a8dddcb0a337c105ff80156412ea22185c12b6->leave($__internal_38fec5e1fe9a52f6fc84b9e953a8dddcb0a337c105ff80156412ea22185c12b6_prof);

        
        $__internal_1b44f3fa8efba05713cf6aab3a8c515ae0298a41b68dc4e8b0b81f0521324909->leave($__internal_1b44f3fa8efba05713cf6aab3a8c515ae0298a41b68dc4e8b0b81f0521324909_prof);

    }

    public function getTemplateName()
    {
        return "post/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Post creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('post_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "post/new.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/app/Resources/views/post/new.html.twig");
    }
}
