<?php

/* post/edit.html.twig */
class __TwigTemplate_6d9c3a2997287380073308e5bceee5529a38b0a9f79a5a15f3b4ae8ff880f236 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "post/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f84f9feafd0084cb2bf884ab70e4c528c1ec0d5bc068604a00ee6e27e73a1cbb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f84f9feafd0084cb2bf884ab70e4c528c1ec0d5bc068604a00ee6e27e73a1cbb->enter($__internal_f84f9feafd0084cb2bf884ab70e4c528c1ec0d5bc068604a00ee6e27e73a1cbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/edit.html.twig"));

        $__internal_45e92a19ca74c9e0ce9b8b79a147270496855fdbc124304b1e0e46f4b5b9692d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45e92a19ca74c9e0ce9b8b79a147270496855fdbc124304b1e0e46f4b5b9692d->enter($__internal_45e92a19ca74c9e0ce9b8b79a147270496855fdbc124304b1e0e46f4b5b9692d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "post/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f84f9feafd0084cb2bf884ab70e4c528c1ec0d5bc068604a00ee6e27e73a1cbb->leave($__internal_f84f9feafd0084cb2bf884ab70e4c528c1ec0d5bc068604a00ee6e27e73a1cbb_prof);

        
        $__internal_45e92a19ca74c9e0ce9b8b79a147270496855fdbc124304b1e0e46f4b5b9692d->leave($__internal_45e92a19ca74c9e0ce9b8b79a147270496855fdbc124304b1e0e46f4b5b9692d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_670a69be5231464f99a71ae438056049f256d4f2468197927de71c15537e7d3f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_670a69be5231464f99a71ae438056049f256d4f2468197927de71c15537e7d3f->enter($__internal_670a69be5231464f99a71ae438056049f256d4f2468197927de71c15537e7d3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3b4509f63d61df147deb38db7d97061df2e3958830a02cede12dbc4adf7f397c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b4509f63d61df147deb38db7d97061df2e3958830a02cede12dbc4adf7f397c->enter($__internal_3b4509f63d61df147deb38db7d97061df2e3958830a02cede12dbc4adf7f397c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Post edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) || array_key_exists("edit_form", $context) ? $context["edit_form"] : (function () { throw new Twig_Error_Runtime('Variable "edit_form" does not exist.', 6, $this->getSourceContext()); })()), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) || array_key_exists("edit_form", $context) ? $context["edit_form"] : (function () { throw new Twig_Error_Runtime('Variable "edit_form" does not exist.', 7, $this->getSourceContext()); })()), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) || array_key_exists("edit_form", $context) ? $context["edit_form"] : (function () { throw new Twig_Error_Runtime('Variable "edit_form" does not exist.', 9, $this->getSourceContext()); })()), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) || array_key_exists("delete_form", $context) ? $context["delete_form"] : (function () { throw new Twig_Error_Runtime('Variable "delete_form" does not exist.', 16, $this->getSourceContext()); })()), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) || array_key_exists("delete_form", $context) ? $context["delete_form"] : (function () { throw new Twig_Error_Runtime('Variable "delete_form" does not exist.', 18, $this->getSourceContext()); })()), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_3b4509f63d61df147deb38db7d97061df2e3958830a02cede12dbc4adf7f397c->leave($__internal_3b4509f63d61df147deb38db7d97061df2e3958830a02cede12dbc4adf7f397c_prof);

        
        $__internal_670a69be5231464f99a71ae438056049f256d4f2468197927de71c15537e7d3f->leave($__internal_670a69be5231464f99a71ae438056049f256d4f2468197927de71c15537e7d3f_prof);

    }

    public function getTemplateName()
    {
        return "post/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Post edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('post_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "post/edit.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/app/Resources/views/post/edit.html.twig");
    }
}
