<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_497225e4569129a078a6a63512c7401f875ea68e700e2e7e23538f42dd8c002d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_844cb20b787199bd82902eccdcea676283717293db748998a736b673f1dd8fa4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_844cb20b787199bd82902eccdcea676283717293db748998a736b673f1dd8fa4->enter($__internal_844cb20b787199bd82902eccdcea676283717293db748998a736b673f1dd8fa4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_979740d44e12b65490f333c4bbfd72ae089b5536e05540e3d2980f51336b60c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_979740d44e12b65490f333c4bbfd72ae089b5536e05540e3d2980f51336b60c2->enter($__internal_979740d44e12b65490f333c4bbfd72ae089b5536e05540e3d2980f51336b60c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_844cb20b787199bd82902eccdcea676283717293db748998a736b673f1dd8fa4->leave($__internal_844cb20b787199bd82902eccdcea676283717293db748998a736b673f1dd8fa4_prof);

        
        $__internal_979740d44e12b65490f333c4bbfd72ae089b5536e05540e3d2980f51336b60c2->leave($__internal_979740d44e12b65490f333c4bbfd72ae089b5536e05540e3d2980f51336b60c2_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}
