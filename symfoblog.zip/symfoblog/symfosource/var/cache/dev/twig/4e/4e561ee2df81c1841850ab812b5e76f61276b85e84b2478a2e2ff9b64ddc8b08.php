<?php

/* CABlogBundle:Session:login.html.twig */
class __TwigTemplate_f2c5a87f70d252ffe13653c8124222e7c5aa68ffa1dec39ce98eb8bd84c7f5dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "CABlogBundle:Session:login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c15cc97792c1264a52cbe0af5a247b2ffb82371fa08279883856f660ef48117 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2c15cc97792c1264a52cbe0af5a247b2ffb82371fa08279883856f660ef48117->enter($__internal_2c15cc97792c1264a52cbe0af5a247b2ffb82371fa08279883856f660ef48117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CABlogBundle:Session:login.html.twig"));

        $__internal_c3d43eb8cb45ae8e98a8bd5841a2d3684265668f80f4968f683be5a242055b2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3d43eb8cb45ae8e98a8bd5841a2d3684265668f80f4968f683be5a242055b2b->enter($__internal_c3d43eb8cb45ae8e98a8bd5841a2d3684265668f80f4968f683be5a242055b2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CABlogBundle:Session:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2c15cc97792c1264a52cbe0af5a247b2ffb82371fa08279883856f660ef48117->leave($__internal_2c15cc97792c1264a52cbe0af5a247b2ffb82371fa08279883856f660ef48117_prof);

        
        $__internal_c3d43eb8cb45ae8e98a8bd5841a2d3684265668f80f4968f683be5a242055b2b->leave($__internal_c3d43eb8cb45ae8e98a8bd5841a2d3684265668f80f4968f683be5a242055b2b_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_ddf5ffc87e3dd361092001b898dce526a5410a24c56682e2cb8292701001281c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ddf5ffc87e3dd361092001b898dce526a5410a24c56682e2cb8292701001281c->enter($__internal_ddf5ffc87e3dd361092001b898dce526a5410a24c56682e2cb8292701001281c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_fe3524c62b9c559363d7b2984659523b99bf0bf415cf08486dc3a3e938020643 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe3524c62b9c559363d7b2984659523b99bf0bf415cf08486dc3a3e938020643->enter($__internal_fe3524c62b9c559363d7b2984659523b99bf0bf415cf08486dc3a3e938020643_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "CABlogBundle:Session:login";
        
        $__internal_fe3524c62b9c559363d7b2984659523b99bf0bf415cf08486dc3a3e938020643->leave($__internal_fe3524c62b9c559363d7b2984659523b99bf0bf415cf08486dc3a3e938020643_prof);

        
        $__internal_ddf5ffc87e3dd361092001b898dce526a5410a24c56682e2cb8292701001281c->leave($__internal_ddf5ffc87e3dd361092001b898dce526a5410a24c56682e2cb8292701001281c_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_0811f1591e421624de06893d86c7eae6dd0d01c35bbc49b95fcaa02fb9fa6431 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0811f1591e421624de06893d86c7eae6dd0d01c35bbc49b95fcaa02fb9fa6431->enter($__internal_0811f1591e421624de06893d86c7eae6dd0d01c35bbc49b95fcaa02fb9fa6431_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e4a4800a758eabd0933102d342f5e954e217ee283750909ca58187f52c981ae5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4a4800a758eabd0933102d342f5e954e217ee283750909ca58187f52c981ae5->enter($__internal_e4a4800a758eabd0933102d342f5e954e217ee283750909ca58187f52c981ae5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Login page</h1>

";
        // line 8
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 8, $this->getSourceContext()); })())) {
            // line 9
            echo "    <div id=\"connection_error\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 9, $this->getSourceContext()); })()), "messageKey", array()), "html", null, true);
            echo "</div>
";
        }
        // line 11
        echo "
<form action=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\" method=\"post\">
\t<label for=\"username\">Username:</label>
\t<input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new Twig_Error_Runtime('Variable "last_username" does not exist.', 14, $this->getSourceContext()); })()), "html", null, true);
        echo "\" />

\t<label for=\"password\">Password:</label>
\t<input type=\"password\" id=\"password\" name=\"_password\" />

\t<input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" checked />
    <label for=\"remember_me\">Remember me</label>

\t<button type=\"submit\">login</button>
</form>
";
        
        $__internal_e4a4800a758eabd0933102d342f5e954e217ee283750909ca58187f52c981ae5->leave($__internal_e4a4800a758eabd0933102d342f5e954e217ee283750909ca58187f52c981ae5_prof);

        
        $__internal_0811f1591e421624de06893d86c7eae6dd0d01c35bbc49b95fcaa02fb9fa6431->leave($__internal_0811f1591e421624de06893d86c7eae6dd0d01c35bbc49b95fcaa02fb9fa6431_prof);

    }

    public function getTemplateName()
    {
        return "CABlogBundle:Session:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 14,  83 => 12,  80 => 11,  74 => 9,  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}

{% block title %}CABlogBundle:Session:login{% endblock %}

{% block body %}
<h1>Login page</h1>

{% if error %}
    <div id=\"connection_error\">{{ error.messageKey }}</div>
{% endif %}

<form action=\"{{ path('login') }}\" method=\"post\">
\t<label for=\"username\">Username:</label>
\t<input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" />

\t<label for=\"password\">Password:</label>
\t<input type=\"password\" id=\"password\" name=\"_password\" />

\t<input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" checked />
    <label for=\"remember_me\">Remember me</label>

\t<button type=\"submit\">login</button>
</form>
{% endblock %}
", "CABlogBundle:Session:login.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/src/CA/BlogBundle/Resources/views/Session/login.html.twig");
    }
}
