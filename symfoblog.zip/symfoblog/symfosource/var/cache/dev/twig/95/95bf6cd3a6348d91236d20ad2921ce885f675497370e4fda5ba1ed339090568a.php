<?php

/* @Twig/images/icon-minus-square-o.svg */
class __TwigTemplate_8828e47790d414f0713346ee4f39cf5ed650d96d0374522c166c5758752da368 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76e746455b896e33f34a9274528479363d21c68a0c5081028ba9397558b45d0b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76e746455b896e33f34a9274528479363d21c68a0c5081028ba9397558b45d0b->enter($__internal_76e746455b896e33f34a9274528479363d21c68a0c5081028ba9397558b45d0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square-o.svg"));

        $__internal_79d9c4a96cec2ddffe6ff70c2a1c6bed85e740ec378c93db99d0c820a5908984 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79d9c4a96cec2ddffe6ff70c2a1c6bed85e740ec378c93db99d0c820a5908984->enter($__internal_79d9c4a96cec2ddffe6ff70c2a1c6bed85e740ec378c93db99d0c820a5908984_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square-o.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1344 800v64q0 14-9 23t-23 9H480q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h832q14 0 23 9t9 23zm128 448V416q0-66-47-113t-113-47H480q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113zm128-832v832q0 119-84.5 203.5T1312 1536H480q-119 0-203.5-84.5T192 1248V416q0-119 84.5-203.5T480 128h832q119 0 203.5 84.5T1600 416z\"/></svg>
";
        
        $__internal_76e746455b896e33f34a9274528479363d21c68a0c5081028ba9397558b45d0b->leave($__internal_76e746455b896e33f34a9274528479363d21c68a0c5081028ba9397558b45d0b_prof);

        
        $__internal_79d9c4a96cec2ddffe6ff70c2a1c6bed85e740ec378c93db99d0c820a5908984->leave($__internal_79d9c4a96cec2ddffe6ff70c2a1c6bed85e740ec378c93db99d0c820a5908984_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square-o.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1344 800v64q0 14-9 23t-23 9H480q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h832q14 0 23 9t9 23zm128 448V416q0-66-47-113t-113-47H480q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113zm128-832v832q0 119-84.5 203.5T1312 1536H480q-119 0-203.5-84.5T192 1248V416q0-119 84.5-203.5T480 128h832q119 0 203.5 84.5T1600 416z\"/></svg>
", "@Twig/images/icon-minus-square-o.svg", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-minus-square-o.svg");
    }
}
