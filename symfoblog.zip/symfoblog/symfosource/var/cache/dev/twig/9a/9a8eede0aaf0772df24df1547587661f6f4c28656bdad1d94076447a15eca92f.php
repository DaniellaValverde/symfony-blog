<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_5fa6ce5b6ae6f7f180e7b24b6ffd6def7a1ce435a21fe411c523c7512f6710ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_faf74edead51fd1f38f82b7fadc81831048265b59b4b9de05c4ffa5528e45af8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_faf74edead51fd1f38f82b7fadc81831048265b59b4b9de05c4ffa5528e45af8->enter($__internal_faf74edead51fd1f38f82b7fadc81831048265b59b4b9de05c4ffa5528e45af8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_057158ec017cf4ba603eb6d19d4ce337a03db40089b43607e25297c25b2b4e95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_057158ec017cf4ba603eb6d19d4ce337a03db40089b43607e25297c25b2b4e95->enter($__internal_057158ec017cf4ba603eb6d19d4ce337a03db40089b43607e25297c25b2b4e95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_faf74edead51fd1f38f82b7fadc81831048265b59b4b9de05c4ffa5528e45af8->leave($__internal_faf74edead51fd1f38f82b7fadc81831048265b59b4b9de05c4ffa5528e45af8_prof);

        
        $__internal_057158ec017cf4ba603eb6d19d4ce337a03db40089b43607e25297c25b2b4e95->leave($__internal_057158ec017cf4ba603eb6d19d4ce337a03db40089b43607e25297c25b2b4e95_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/icon-minus-square.svg");
    }
}
