<?php

/* user/show.html.twig */
class __TwigTemplate_681a5e548c428d5a6a3fc4b3dd4b19b19c8b5c4558fd935fdfcfda281594ee26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_307b6c785159f7eaeb71d3b88823618abd36f8ea0597fe48f5800c521c9a3036 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_307b6c785159f7eaeb71d3b88823618abd36f8ea0597fe48f5800c521c9a3036->enter($__internal_307b6c785159f7eaeb71d3b88823618abd36f8ea0597fe48f5800c521c9a3036_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/show.html.twig"));

        $__internal_df8a8842cf180c19e0441cea5fd0cd4d61013108ec0d93156145ad40d09963b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df8a8842cf180c19e0441cea5fd0cd4d61013108ec0d93156145ad40d09963b0->enter($__internal_df8a8842cf180c19e0441cea5fd0cd4d61013108ec0d93156145ad40d09963b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_307b6c785159f7eaeb71d3b88823618abd36f8ea0597fe48f5800c521c9a3036->leave($__internal_307b6c785159f7eaeb71d3b88823618abd36f8ea0597fe48f5800c521c9a3036_prof);

        
        $__internal_df8a8842cf180c19e0441cea5fd0cd4d61013108ec0d93156145ad40d09963b0->leave($__internal_df8a8842cf180c19e0441cea5fd0cd4d61013108ec0d93156145ad40d09963b0_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_02199e9d93ec00b160cea8b56e5f03103992cca7195dd8ec494c8719d9a7ee5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02199e9d93ec00b160cea8b56e5f03103992cca7195dd8ec494c8719d9a7ee5a->enter($__internal_02199e9d93ec00b160cea8b56e5f03103992cca7195dd8ec494c8719d9a7ee5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a68c326c6de2526eff1169c5827b8a209b2717377b8e215022a9678583b41180 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a68c326c6de2526eff1169c5827b8a209b2717377b8e215022a9678583b41180->enter($__internal_a68c326c6de2526eff1169c5827b8a209b2717377b8e215022a9678583b41180_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>User's profile</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 10, $this->getSourceContext()); })()), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Username</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 14, $this->getSourceContext()); })()), "username", array()), "html", null, true);
        echo "</td>
            </tr>
            ";
        // line 17
        echo "                ";
        // line 18
        echo "                ";
        // line 19
        echo "            ";
        // line 20
        echo "            ";
        // line 21
        echo "                ";
        // line 22
        echo "                ";
        // line 23
        echo "            ";
        // line 24
        echo "            <tr>
                <th>Mail</th>
                <td>";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 26, $this->getSourceContext()); })()), "mail", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Roles</th>
                <td>";
        // line 30
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 30, $this->getSourceContext()); })()), "roles", array())) {
            echo twig_escape_filter($this->env, twig_join_filter(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 30, $this->getSourceContext()); })()), "roles", array()), ", "), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_edit", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 40, $this->getSourceContext()); })()), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 43
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) || array_key_exists("delete_form", $context) ? $context["delete_form"] : (function () { throw new Twig_Error_Runtime('Variable "delete_form" does not exist.', 43, $this->getSourceContext()); })()), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 45
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) || array_key_exists("delete_form", $context) ? $context["delete_form"] : (function () { throw new Twig_Error_Runtime('Variable "delete_form" does not exist.', 45, $this->getSourceContext()); })()), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_a68c326c6de2526eff1169c5827b8a209b2717377b8e215022a9678583b41180->leave($__internal_a68c326c6de2526eff1169c5827b8a209b2717377b8e215022a9678583b41180_prof);

        
        $__internal_02199e9d93ec00b160cea8b56e5f03103992cca7195dd8ec494c8719d9a7ee5a->leave($__internal_02199e9d93ec00b160cea8b56e5f03103992cca7195dd8ec494c8719d9a7ee5a_prof);

    }

    public function getTemplateName()
    {
        return "user/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 45,  118 => 43,  112 => 40,  106 => 37,  94 => 30,  87 => 26,  83 => 24,  81 => 23,  79 => 22,  77 => 21,  75 => 20,  73 => 19,  71 => 18,  69 => 17,  64 => 14,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>User's profile</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ user.id }}</td>
            </tr>
            <tr>
                <th>Username</th>
                <td>{{ user.username }}</td>
            </tr>
            {#<tr>#}
                {#<th>Password</th>#}
                {#<td>{{ user.password }}</td>#}
            {#</tr>#}
            {#<tr>#}
                {#<th>Salt</th>#}
                {#<td>{{ user.salt }}</td>#}
            {#</tr>#}
            <tr>
                <th>Mail</th>
                <td>{{ user.mail }}</td>
            </tr>
            <tr>
                <th>Roles</th>
                <td>{% if user.roles %}{{ user.roles|join(', ') }}{% endif %}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('user_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('user_edit', { 'id': user.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "user/show.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/app/Resources/views/user/show.html.twig");
    }
}
