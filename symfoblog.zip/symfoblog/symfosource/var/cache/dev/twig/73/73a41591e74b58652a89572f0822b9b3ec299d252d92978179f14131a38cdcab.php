<?php

/* base.html.twig */
class __TwigTemplate_83b5e9b24179292353fe88ba51f5993b124411c8d1e7b755b4a700156f836eec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04716e007d7f26cd8cf44ad9c38dcd0d7b1596fd8794001c0e08b9fbe0871220 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04716e007d7f26cd8cf44ad9c38dcd0d7b1596fd8794001c0e08b9fbe0871220->enter($__internal_04716e007d7f26cd8cf44ad9c38dcd0d7b1596fd8794001c0e08b9fbe0871220_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_b0ac29d53e4597dd265af1d1d7d96623f108e1a562fff5e223afaf96799bb4d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0ac29d53e4597dd265af1d1d7d96623f108e1a562fff5e223afaf96799bb4d5->enter($__internal_b0ac29d53e4597dd265af1d1d7d96623f108e1a562fff5e223afaf96799bb4d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <header>
            <div style=\"background-color: #313131\">
                <h1 style=\"color: white\">A Symfony blog example</h1>
                <h2 style=\"color: white\">(Daniella Valverde - december/2017)</h2>
            </div>
            <div style=\"background-color: #666666\">
                <ul style=\"list-style-type: none; display: flex\">
                    ";
        // line 17
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 17, $this->getSourceContext()); })()), "user", array())) {
            // line 18
            echo "                    <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\LogoutUrlExtension')->getLogoutPath(null), "html", null, true);
            echo "\">Logout |</a></li>
                    ";
        } else {
            // line 20
            echo "                    <li><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
            echo "\">Login |</a></li>
                    ";
        }
        // line 22
        echo "                    <li><a style=\"color: white\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\">| Index |</a></li>
                    ";
        // line 24
        echo "                    ";
        // line 25
        echo "                    <li><a style=\"color: white\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_new");
        echo "\">| Register |</a></li>
                    <li><a style=\"color: white\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\">| Users list |</a></li>
                    <li><a style=\"color: white\" href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_index");
        echo "\">| Posts list |</a></li>
                    <li><a style=\"color: white\" href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_new");
        echo "\">| New post</a></li>
                </ul>
            </div>
        </header>
        ";
        // line 32
        $this->displayBlock('body', $context, $blocks);
        // line 33
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 34
        echo "    </body>
</html>
";
        
        $__internal_04716e007d7f26cd8cf44ad9c38dcd0d7b1596fd8794001c0e08b9fbe0871220->leave($__internal_04716e007d7f26cd8cf44ad9c38dcd0d7b1596fd8794001c0e08b9fbe0871220_prof);

        
        $__internal_b0ac29d53e4597dd265af1d1d7d96623f108e1a562fff5e223afaf96799bb4d5->leave($__internal_b0ac29d53e4597dd265af1d1d7d96623f108e1a562fff5e223afaf96799bb4d5_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_cbc812420aaea175115e9a60fc472fb1e86ad8a1825586585e90d2ae8975b1c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbc812420aaea175115e9a60fc472fb1e86ad8a1825586585e90d2ae8975b1c5->enter($__internal_cbc812420aaea175115e9a60fc472fb1e86ad8a1825586585e90d2ae8975b1c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_acc617599b28b756f525e94ecfd9c7f3f0058fa74da3ba239bfb6370215fe069 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acc617599b28b756f525e94ecfd9c7f3f0058fa74da3ba239bfb6370215fe069->enter($__internal_acc617599b28b756f525e94ecfd9c7f3f0058fa74da3ba239bfb6370215fe069_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_acc617599b28b756f525e94ecfd9c7f3f0058fa74da3ba239bfb6370215fe069->leave($__internal_acc617599b28b756f525e94ecfd9c7f3f0058fa74da3ba239bfb6370215fe069_prof);

        
        $__internal_cbc812420aaea175115e9a60fc472fb1e86ad8a1825586585e90d2ae8975b1c5->leave($__internal_cbc812420aaea175115e9a60fc472fb1e86ad8a1825586585e90d2ae8975b1c5_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7a9fdaf1396189907530538bee03bb9d386f0ef64bd9eaceb7b5939292e0a89e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a9fdaf1396189907530538bee03bb9d386f0ef64bd9eaceb7b5939292e0a89e->enter($__internal_7a9fdaf1396189907530538bee03bb9d386f0ef64bd9eaceb7b5939292e0a89e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6cf0d909eb89f30ff396c5613e8c555f03fae797594c8fbda9c6448112551235 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cf0d909eb89f30ff396c5613e8c555f03fae797594c8fbda9c6448112551235->enter($__internal_6cf0d909eb89f30ff396c5613e8c555f03fae797594c8fbda9c6448112551235_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_6cf0d909eb89f30ff396c5613e8c555f03fae797594c8fbda9c6448112551235->leave($__internal_6cf0d909eb89f30ff396c5613e8c555f03fae797594c8fbda9c6448112551235_prof);

        
        $__internal_7a9fdaf1396189907530538bee03bb9d386f0ef64bd9eaceb7b5939292e0a89e->leave($__internal_7a9fdaf1396189907530538bee03bb9d386f0ef64bd9eaceb7b5939292e0a89e_prof);

    }

    // line 32
    public function block_body($context, array $blocks = array())
    {
        $__internal_a2fe3edad567d3bc8fdfe52d72e1eac5a9854d1421c526c37d3079b112436642 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2fe3edad567d3bc8fdfe52d72e1eac5a9854d1421c526c37d3079b112436642->enter($__internal_a2fe3edad567d3bc8fdfe52d72e1eac5a9854d1421c526c37d3079b112436642_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_24b2c8003587947aa7baa0abcbc433443d79f2704d9f51e150a1f58c1f9ad248 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24b2c8003587947aa7baa0abcbc433443d79f2704d9f51e150a1f58c1f9ad248->enter($__internal_24b2c8003587947aa7baa0abcbc433443d79f2704d9f51e150a1f58c1f9ad248_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_24b2c8003587947aa7baa0abcbc433443d79f2704d9f51e150a1f58c1f9ad248->leave($__internal_24b2c8003587947aa7baa0abcbc433443d79f2704d9f51e150a1f58c1f9ad248_prof);

        
        $__internal_a2fe3edad567d3bc8fdfe52d72e1eac5a9854d1421c526c37d3079b112436642->leave($__internal_a2fe3edad567d3bc8fdfe52d72e1eac5a9854d1421c526c37d3079b112436642_prof);

    }

    // line 33
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_df850a49e43149e36b9d744e611cdbaaa1c307aaca211dede1f8d76158f57955 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df850a49e43149e36b9d744e611cdbaaa1c307aaca211dede1f8d76158f57955->enter($__internal_df850a49e43149e36b9d744e611cdbaaa1c307aaca211dede1f8d76158f57955_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_4fa3a484e6c1ec67e08e9c01acd91c3cad6635e7fd5e12e7a6ba01ab6f828e68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fa3a484e6c1ec67e08e9c01acd91c3cad6635e7fd5e12e7a6ba01ab6f828e68->enter($__internal_4fa3a484e6c1ec67e08e9c01acd91c3cad6635e7fd5e12e7a6ba01ab6f828e68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4fa3a484e6c1ec67e08e9c01acd91c3cad6635e7fd5e12e7a6ba01ab6f828e68->leave($__internal_4fa3a484e6c1ec67e08e9c01acd91c3cad6635e7fd5e12e7a6ba01ab6f828e68_prof);

        
        $__internal_df850a49e43149e36b9d744e611cdbaaa1c307aaca211dede1f8d76158f57955->leave($__internal_df850a49e43149e36b9d744e611cdbaaa1c307aaca211dede1f8d76158f57955_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 33,  148 => 32,  131 => 6,  113 => 5,  101 => 34,  98 => 33,  96 => 32,  89 => 28,  85 => 27,  81 => 26,  76 => 25,  74 => 24,  69 => 22,  63 => 20,  57 => 18,  55 => 17,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        <header>
            <div style=\"background-color: #313131\">
                <h1 style=\"color: white\">A Symfony blog example</h1>
                <h2 style=\"color: white\">(Daniella Valverde - december/2017)</h2>
            </div>
            <div style=\"background-color: #666666\">
                <ul style=\"list-style-type: none; display: flex\">
                    {% if app.user %}
                    <li><a href=\"{{ logout_path(key = null) }}\">Logout |</a></li>
                    {% else %}
                    <li><a href=\"{{ path('login') }}\">Login |</a></li>
                    {% endif %}
                    <li><a style=\"color: white\" href=\"{{ path('index') }}\">| Index |</a></li>
                    {#<li><a style=\"color: white\" href=\"{{ path('login') }}\">| Login |</a></li>#}
                    {#<li><a style=\"color: white\" href=\"{{ path('logout') }}\">| Logout |</a></li>#}
                    <li><a style=\"color: white\" href=\"{{ path('user_new') }}\">| Register |</a></li>
                    <li><a style=\"color: white\" href=\"{{ path('user_index') }}\">| Users list |</a></li>
                    <li><a style=\"color: white\" href=\"{{ path('post_index') }}\">| Posts list |</a></li>
                    <li><a style=\"color: white\" href=\"{{ path('post_new') }}\">| New post</a></li>
                </ul>
            </div>
        </header>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/Users/daniellavalverde/Documents/CODING-ACADEMY/symfoblog/symfosource/app/Resources/views/base.html.twig");
    }
}
