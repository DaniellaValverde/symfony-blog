<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_f80b1eb8133ce2f1327e469d2067b6386b3f775cc04d0b50eb74197424412f04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5bb260adab6a652ff0367cb189b8cea28699c23a606d27f3c2528f66e14cf39c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5bb260adab6a652ff0367cb189b8cea28699c23a606d27f3c2528f66e14cf39c->enter($__internal_5bb260adab6a652ff0367cb189b8cea28699c23a606d27f3c2528f66e14cf39c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_6a1281d0002cb9fd671f0d38c8e930970d3a3a9e7793fbf32be9844c80c107c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6a1281d0002cb9fd671f0d38c8e930970d3a3a9e7793fbf32be9844c80c107c3->enter($__internal_6a1281d0002cb9fd671f0d38c8e930970d3a3a9e7793fbf32be9844c80c107c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5bb260adab6a652ff0367cb189b8cea28699c23a606d27f3c2528f66e14cf39c->leave($__internal_5bb260adab6a652ff0367cb189b8cea28699c23a606d27f3c2528f66e14cf39c_prof);

        
        $__internal_6a1281d0002cb9fd671f0d38c8e930970d3a3a9e7793fbf32be9844c80c107c3->leave($__internal_6a1281d0002cb9fd671f0d38c8e930970d3a3a9e7793fbf32be9844c80c107c3_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a0d4118d736a749eb5321a2e69ba33dd572f5bcc4e4fd66588291facaa622a66 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0d4118d736a749eb5321a2e69ba33dd572f5bcc4e4fd66588291facaa622a66->enter($__internal_a0d4118d736a749eb5321a2e69ba33dd572f5bcc4e4fd66588291facaa622a66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_1a8e508e26695231c51f637b81fc1c90d20b9532b1a7b6eebb56e9e22f2f1a3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a8e508e26695231c51f637b81fc1c90d20b9532b1a7b6eebb56e9e22f2f1a3b->enter($__internal_1a8e508e26695231c51f637b81fc1c90d20b9532b1a7b6eebb56e9e22f2f1a3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_1a8e508e26695231c51f637b81fc1c90d20b9532b1a7b6eebb56e9e22f2f1a3b->leave($__internal_1a8e508e26695231c51f637b81fc1c90d20b9532b1a7b6eebb56e9e22f2f1a3b_prof);

        
        $__internal_a0d4118d736a749eb5321a2e69ba33dd572f5bcc4e4fd66588291facaa622a66->leave($__internal_a0d4118d736a749eb5321a2e69ba33dd572f5bcc4e4fd66588291facaa622a66_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e27835c2df81df7c741e72a39d85318295aa8c9486062508a93baed41b9eb608 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e27835c2df81df7c741e72a39d85318295aa8c9486062508a93baed41b9eb608->enter($__internal_e27835c2df81df7c741e72a39d85318295aa8c9486062508a93baed41b9eb608_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ba48f3de732f2be448e477c919582dc675c840be0bb47d46fdb6cbbc87831ced = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba48f3de732f2be448e477c919582dc675c840be0bb47d46fdb6cbbc87831ced->enter($__internal_ba48f3de732f2be448e477c919582dc675c840be0bb47d46fdb6cbbc87831ced_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_ba48f3de732f2be448e477c919582dc675c840be0bb47d46fdb6cbbc87831ced->leave($__internal_ba48f3de732f2be448e477c919582dc675c840be0bb47d46fdb6cbbc87831ced_prof);

        
        $__internal_e27835c2df81df7c741e72a39d85318295aa8c9486062508a93baed41b9eb608->leave($__internal_e27835c2df81df7c741e72a39d85318295aa8c9486062508a93baed41b9eb608_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_864499e9dd5568c0d22cd9e87a35427134a1fd56950fb22b528aaefdb14370bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_864499e9dd5568c0d22cd9e87a35427134a1fd56950fb22b528aaefdb14370bb->enter($__internal_864499e9dd5568c0d22cd9e87a35427134a1fd56950fb22b528aaefdb14370bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_22866f0726f27993a8de8600037e4e4305fb40195b4bd7827646ccc3f6ade516 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22866f0726f27993a8de8600037e4e4305fb40195b4bd7827646ccc3f6ade516->enter($__internal_22866f0726f27993a8de8600037e4e4305fb40195b4bd7827646ccc3f6ade516_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_22866f0726f27993a8de8600037e4e4305fb40195b4bd7827646ccc3f6ade516->leave($__internal_22866f0726f27993a8de8600037e4e4305fb40195b4bd7827646ccc3f6ade516_prof);

        
        $__internal_864499e9dd5568c0d22cd9e87a35427134a1fd56950fb22b528aaefdb14370bb->leave($__internal_864499e9dd5568c0d22cd9e87a35427134a1fd56950fb22b528aaefdb14370bb_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
