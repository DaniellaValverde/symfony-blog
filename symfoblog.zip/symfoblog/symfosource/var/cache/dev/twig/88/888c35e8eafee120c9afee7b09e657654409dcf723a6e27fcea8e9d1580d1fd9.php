<?php

/* user/id.html.twig */
class __TwigTemplate_ac7dd2f6c6dffb7877788e17b338b01df5f21d0349d0ffe7b42ae3eaf8e2e3e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/id.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c736f9a73f8542e5443e2f4cb9b7d95d045b2d55696575af847d4cfcc6d2b5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c736f9a73f8542e5443e2f4cb9b7d95d045b2d55696575af847d4cfcc6d2b5b->enter($__internal_0c736f9a73f8542e5443e2f4cb9b7d95d045b2d55696575af847d4cfcc6d2b5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/id.html.twig"));

        $__internal_1055cca81226190da6942b896d89cad56379749a49161e158aa871012570fca9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1055cca81226190da6942b896d89cad56379749a49161e158aa871012570fca9->enter($__internal_1055cca81226190da6942b896d89cad56379749a49161e158aa871012570fca9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/id.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0c736f9a73f8542e5443e2f4cb9b7d95d045b2d55696575af847d4cfcc6d2b5b->leave($__internal_0c736f9a73f8542e5443e2f4cb9b7d95d045b2d55696575af847d4cfcc6d2b5b_prof);

        
        $__internal_1055cca81226190da6942b896d89cad56379749a49161e158aa871012570fca9->leave($__internal_1055cca81226190da6942b896d89cad56379749a49161e158aa871012570fca9_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a65ee7f99166dd14aa07de65c224d714e2dbaba9d26dee73d57ba93e28df80bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a65ee7f99166dd14aa07de65c224d714e2dbaba9d26dee73d57ba93e28df80bc->enter($__internal_a65ee7f99166dd14aa07de65c224d714e2dbaba9d26dee73d57ba93e28df80bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f83706f0fb10eb9d7a59d948316538c7891135c2d53ec6c2ae2e2d644ab9595c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f83706f0fb10eb9d7a59d948316538c7891135c2d53ec6c2ae2e2d644ab9595c->enter($__internal_f83706f0fb10eb9d7a59d948316538c7891135c2d53ec6c2ae2e2d644ab9595c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 4, $this->getSourceContext()); })()), "username", array()), "html", null, true);
        echo "</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 10, $this->getSourceContext()); })()), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Mail</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 14, $this->getSourceContext()); })()), "mail", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Roles</th>
                <td>";
        // line 18
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 18, $this->getSourceContext()); })()), "roles", array())) {
            echo twig_escape_filter($this->env, twig_join_filter(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 18, $this->getSourceContext()); })()), "roles", array()), ", "), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>


    <h2>";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 24, $this->getSourceContext()); })()), "username", array()), "html", null, true);
        echo "'s posts</h2>

        ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new Twig_Error_Runtime('Variable "posts" does not exist.', 26, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 27
            echo "
            ";
            // line 28
            if ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "user", array()), "id", array()) == twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 28, $this->getSourceContext()); })()), "id", array()))) {
                // line 29
                echo "
            <div class='post'>
            <p><a href='";
                // line 31
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_show", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "id", array()))), "html", null, true);
                echo "'>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "title", array()), "html", null, true);
                echo "</a>(";
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "created", array())) {
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "created", array()), "Y-m-d H:i:s"), "html", null, true);
                }
                echo ")</p>
            <p>";
                // line 32
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "content", array()), "html", null, true);
                echo "</p>
            </div>

            ";
            }
            // line 36
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "
    

";
        
        $__internal_f83706f0fb10eb9d7a59d948316538c7891135c2d53ec6c2ae2e2d644ab9595c->leave($__internal_f83706f0fb10eb9d7a59d948316538c7891135c2d53ec6c2ae2e2d644ab9595c_prof);

        
        $__internal_a65ee7f99166dd14aa07de65c224d714e2dbaba9d26dee73d57ba93e28df80bc->leave($__internal_a65ee7f99166dd14aa07de65c224d714e2dbaba9d26dee73d57ba93e28df80bc_prof);

    }

    public function getTemplateName()
    {
        return "user/id.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 37,  119 => 36,  112 => 32,  102 => 31,  98 => 29,  96 => 28,  93 => 27,  89 => 26,  84 => 24,  73 => 18,  66 => 14,  59 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>{{ user.username }}</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ user.id }}</td>
            </tr>
            <tr>
                <th>Mail</th>
                <td>{{ user.mail }}</td>
            </tr>
            <tr>
                <th>Roles</th>
                <td>{% if user.roles %}{{ user.roles|join(', ') }}{% endif %}</td>
            </tr>
        </tbody>
    </table>


    <h2>{{ user.username }}'s posts</h2>

        {% for post in posts %}

            {% if post.user.id == user.id %}

            <div class='post'>
            <p><a href='{{ path('post_show', { 'id': post.id }) }}'>{{ post.title }}</a>({% if post.created %}{{ post.created|date('Y-m-d H:i:s') }}{% endif %})</p>
            <p>{{ post.content }}</p>
            </div>

            {% endif %}
    {% endfor %}

    

{% endblock %}", "user/id.html.twig", "/Users/daniellavalverde/Documents/CODING-ACADEMY/symfoblog/symfosource/app/Resources/views/user/id.html.twig");
    }
}
