<?php

/* CABlogBundle:Blog:index.html.twig */
class __TwigTemplate_730b30b73e0c6da350a23dfbfe4c53ab17cb1d017a0d445dc37164941fb26131 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "CABlogBundle:Blog:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e93fe4c8fc108e188fd80313e4a3e2f14dd7f11c09106617aee507d0e5c71f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e93fe4c8fc108e188fd80313e4a3e2f14dd7f11c09106617aee507d0e5c71f0->enter($__internal_6e93fe4c8fc108e188fd80313e4a3e2f14dd7f11c09106617aee507d0e5c71f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CABlogBundle:Blog:index.html.twig"));

        $__internal_71f807d3f17e2b341c8dd28223ba0c69e04df31f65631c8b820dae08841551c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_71f807d3f17e2b341c8dd28223ba0c69e04df31f65631c8b820dae08841551c3->enter($__internal_71f807d3f17e2b341c8dd28223ba0c69e04df31f65631c8b820dae08841551c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CABlogBundle:Blog:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e93fe4c8fc108e188fd80313e4a3e2f14dd7f11c09106617aee507d0e5c71f0->leave($__internal_6e93fe4c8fc108e188fd80313e4a3e2f14dd7f11c09106617aee507d0e5c71f0_prof);

        
        $__internal_71f807d3f17e2b341c8dd28223ba0c69e04df31f65631c8b820dae08841551c3->leave($__internal_71f807d3f17e2b341c8dd28223ba0c69e04df31f65631c8b820dae08841551c3_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b8e310679b5f3e4de8f544290e671f2046a56c2a30c34f7395a27677b6f47e34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8e310679b5f3e4de8f544290e671f2046a56c2a30c34f7395a27677b6f47e34->enter($__internal_b8e310679b5f3e4de8f544290e671f2046a56c2a30c34f7395a27677b6f47e34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c070e4c320ec8407c2bd6f19984ff049eed919d08febe951b2f7d081cc6823cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c070e4c320ec8407c2bd6f19984ff049eed919d08febe951b2f7d081cc6823cf->enter($__internal_c070e4c320ec8407c2bd6f19984ff049eed919d08febe951b2f7d081cc6823cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "CABlogBundle:Blog:index";
        
        $__internal_c070e4c320ec8407c2bd6f19984ff049eed919d08febe951b2f7d081cc6823cf->leave($__internal_c070e4c320ec8407c2bd6f19984ff049eed919d08febe951b2f7d081cc6823cf_prof);

        
        $__internal_b8e310679b5f3e4de8f544290e671f2046a56c2a30c34f7395a27677b6f47e34->leave($__internal_b8e310679b5f3e4de8f544290e671f2046a56c2a30c34f7395a27677b6f47e34_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_38b564130c0e16a76294a1d6c2efbc75ec82ac86914a98f6ceccda4e55c7fb2b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38b564130c0e16a76294a1d6c2efbc75ec82ac86914a98f6ceccda4e55c7fb2b->enter($__internal_38b564130c0e16a76294a1d6c2efbc75ec82ac86914a98f6ceccda4e55c7fb2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5a291f1c2a1a11660a7129db0e84fc8b1bb2e955b5d57358ae22c44741615d43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a291f1c2a1a11660a7129db0e84fc8b1bb2e955b5d57358ae22c44741615d43->enter($__internal_5a291f1c2a1a11660a7129db0e84fc8b1bb2e955b5d57358ae22c44741615d43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "

";
        // line 8
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 8, $this->getSourceContext()); })()), "user", array())) {
            // line 9
            echo "\t<a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\LogoutUrlExtension')->getLogoutPath(null), "html", null, true);
            echo "\">Logout</a>
";
        } else {
            // line 11
            echo "\t<a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
            echo "\">Login</a>
";
        }
        // line 13
        echo "
<h1>Welcome to the Blog: index page</h1>

<h2>Blogroll</h2>

\t<div class='post'>

\t\t";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_slice($this->env, (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new Twig_Error_Runtime('Variable "posts" does not exist.', 20, $this->getSourceContext()); })()), 0, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 21
            echo "
\t\t\t<p><a href='";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("post_show", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "id", array()))), "html", null, true);
            echo "'>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "title", array()), "html", null, true);
            echo "</a>(";
            if (twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "created", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "created", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo ") by 

\t\t\t";
            // line 24
            if (twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "user", array())) {
                // line 25
                echo "\t\t\t\t<a href='";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_id", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "user", array()), "id", array()))), "html", null, true);
                echo "'>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "user", array()), "username", array()), "html", null, true);
                echo "</a></p>
\t\t\t";
            } else {
                // line 27
                echo "\t\t\t\tUnknown</p>
\t\t\t";
            }
            // line 29
            echo "
\t\t\t<p>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["post"], "content", array()), "html", null, true);
            echo "</p>

\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "
\t</div>

";
        
        $__internal_5a291f1c2a1a11660a7129db0e84fc8b1bb2e955b5d57358ae22c44741615d43->leave($__internal_5a291f1c2a1a11660a7129db0e84fc8b1bb2e955b5d57358ae22c44741615d43_prof);

        
        $__internal_38b564130c0e16a76294a1d6c2efbc75ec82ac86914a98f6ceccda4e55c7fb2b->leave($__internal_38b564130c0e16a76294a1d6c2efbc75ec82ac86914a98f6ceccda4e55c7fb2b_prof);

    }

    public function getTemplateName()
    {
        return "CABlogBundle:Blog:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 33,  130 => 30,  127 => 29,  123 => 27,  115 => 25,  113 => 24,  102 => 22,  99 => 21,  95 => 20,  86 => 13,  80 => 11,  74 => 9,  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}

{% block title %}CABlogBundle:Blog:index{% endblock %}

{% block body %}


{% if app.user %}
\t<a href=\"{{ logout_path(key = null) }}\">Logout</a>
{% else %}
\t<a href=\"{{ path('login') }}\">Login</a>
{% endif %}

<h1>Welcome to the Blog: index page</h1>

<h2>Blogroll</h2>

\t<div class='post'>

\t\t{% for post in posts |slice(0, 10) %}

\t\t\t<p><a href='{{ path('post_show', { 'id': post.id }) }}'>{{ post.title }}</a>({% if post.created %}{{ post.created|date('Y-m-d H:i:s') }}{% endif %}) by 

\t\t\t{% if post.user %}
\t\t\t\t<a href='{{ path('user_id', { 'id': post.user.id }) }}'>{{ post.user.username }}</a></p>
\t\t\t{% else %}
\t\t\t\tUnknown</p>
\t\t\t{% endif %}

\t\t\t<p>{{ post.content }}</p>

\t\t{% endfor %}

\t</div>

{% endblock %}
", "CABlogBundle:Blog:index.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/src/CA/BlogBundle/Resources/views/Blog/index.html.twig");
    }
}
