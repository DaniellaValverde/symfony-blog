<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_2dd97f27ac5f89f865cd89a67f3139f287d1870106b58a513127a69dba998323 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae68989e9d609022a7f59ae9109c7d561f2e33319d1af882f4139b2b4e00a80d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae68989e9d609022a7f59ae9109c7d561f2e33319d1af882f4139b2b4e00a80d->enter($__internal_ae68989e9d609022a7f59ae9109c7d561f2e33319d1af882f4139b2b4e00a80d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_209b09ef7e55d08e0734b4644e2fff5ea3a6b77ac3115677cf08a4b428049f9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_209b09ef7e55d08e0734b4644e2fff5ea3a6b77ac3115677cf08a4b428049f9c->enter($__internal_209b09ef7e55d08e0734b4644e2fff5ea3a6b77ac3115677cf08a4b428049f9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_ae68989e9d609022a7f59ae9109c7d561f2e33319d1af882f4139b2b4e00a80d->leave($__internal_ae68989e9d609022a7f59ae9109c7d561f2e33319d1af882f4139b2b4e00a80d_prof);

        
        $__internal_209b09ef7e55d08e0734b4644e2fff5ea3a6b77ac3115677cf08a4b428049f9c->leave($__internal_209b09ef7e55d08e0734b4644e2fff5ea3a6b77ac3115677cf08a4b428049f9c_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_fc2d25463763182a21129ef9263c0b7f313d5ca7dd6cb8bc43567763c6fc4c7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fc2d25463763182a21129ef9263c0b7f313d5ca7dd6cb8bc43567763c6fc4c7a->enter($__internal_fc2d25463763182a21129ef9263c0b7f313d5ca7dd6cb8bc43567763c6fc4c7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_db6b96822b6257fb5329bbc6b97ebf080d632c6c420e384e2984d15a3633e177 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db6b96822b6257fb5329bbc6b97ebf080d632c6c420e384e2984d15a3633e177->enter($__internal_db6b96822b6257fb5329bbc6b97ebf080d632c6c420e384e2984d15a3633e177_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_db6b96822b6257fb5329bbc6b97ebf080d632c6c420e384e2984d15a3633e177->leave($__internal_db6b96822b6257fb5329bbc6b97ebf080d632c6c420e384e2984d15a3633e177_prof);

        
        $__internal_fc2d25463763182a21129ef9263c0b7f313d5ca7dd6cb8bc43567763c6fc4c7a->leave($__internal_fc2d25463763182a21129ef9263c0b7f313d5ca7dd6cb8bc43567763c6fc4c7a_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_84b1cdade1a61b3b1a46155137877f2888fff571ae64d08fd0250cc793e5df15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84b1cdade1a61b3b1a46155137877f2888fff571ae64d08fd0250cc793e5df15->enter($__internal_84b1cdade1a61b3b1a46155137877f2888fff571ae64d08fd0250cc793e5df15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_04c56332249958356e4fbbb608f2215cf03503f136593313514567201dde5d1b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04c56332249958356e4fbbb608f2215cf03503f136593313514567201dde5d1b->enter($__internal_04c56332249958356e4fbbb608f2215cf03503f136593313514567201dde5d1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_04c56332249958356e4fbbb608f2215cf03503f136593313514567201dde5d1b->leave($__internal_04c56332249958356e4fbbb608f2215cf03503f136593313514567201dde5d1b_prof);

        
        $__internal_84b1cdade1a61b3b1a46155137877f2888fff571ae64d08fd0250cc793e5df15->leave($__internal_84b1cdade1a61b3b1a46155137877f2888fff571ae64d08fd0250cc793e5df15_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_b53588ce80027d937b4b3296a70f3582e65afb049a992239aa71ac70d03e7d83 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b53588ce80027d937b4b3296a70f3582e65afb049a992239aa71ac70d03e7d83->enter($__internal_b53588ce80027d937b4b3296a70f3582e65afb049a992239aa71ac70d03e7d83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fea6d940c310821a510d779c98afc30c8bcba9156f32103ed43a27e2f01a8949 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fea6d940c310821a510d779c98afc30c8bcba9156f32103ed43a27e2f01a8949->enter($__internal_fea6d940c310821a510d779c98afc30c8bcba9156f32103ed43a27e2f01a8949_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_fea6d940c310821a510d779c98afc30c8bcba9156f32103ed43a27e2f01a8949->leave($__internal_fea6d940c310821a510d779c98afc30c8bcba9156f32103ed43a27e2f01a8949_prof);

        
        $__internal_b53588ce80027d937b4b3296a70f3582e65afb049a992239aa71ac70d03e7d83->leave($__internal_b53588ce80027d937b4b3296a70f3582e65afb049a992239aa71ac70d03e7d83_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/layout.html.twig");
    }
}
