<?php

/* user/new.html.twig */
class __TwigTemplate_c4aaa66baa51ea785c2619e6fe551221b164caa7378c14f2499955a206663b2c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a66e01ea821ef4999229d6abda2afce986fbf526ca8dad2bc0dd1ea3874f7c88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a66e01ea821ef4999229d6abda2afce986fbf526ca8dad2bc0dd1ea3874f7c88->enter($__internal_a66e01ea821ef4999229d6abda2afce986fbf526ca8dad2bc0dd1ea3874f7c88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/new.html.twig"));

        $__internal_e3acc93025ad4c50ebac6fa9984a9756c32b9aa96bef58fd5bc35eac9af3792c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3acc93025ad4c50ebac6fa9984a9756c32b9aa96bef58fd5bc35eac9af3792c->enter($__internal_e3acc93025ad4c50ebac6fa9984a9756c32b9aa96bef58fd5bc35eac9af3792c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a66e01ea821ef4999229d6abda2afce986fbf526ca8dad2bc0dd1ea3874f7c88->leave($__internal_a66e01ea821ef4999229d6abda2afce986fbf526ca8dad2bc0dd1ea3874f7c88_prof);

        
        $__internal_e3acc93025ad4c50ebac6fa9984a9756c32b9aa96bef58fd5bc35eac9af3792c->leave($__internal_e3acc93025ad4c50ebac6fa9984a9756c32b9aa96bef58fd5bc35eac9af3792c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_fd161cd090e82ec9c35a81a7f04d3b2a9cf4ed148c6aeb9385e89b34f3a4124f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd161cd090e82ec9c35a81a7f04d3b2a9cf4ed148c6aeb9385e89b34f3a4124f->enter($__internal_fd161cd090e82ec9c35a81a7f04d3b2a9cf4ed148c6aeb9385e89b34f3a4124f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ea081a83ac5573dcd9d655db3705c28f6c1566d99cb18f5844b04aa19aeecf54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea081a83ac5573dcd9d655db3705c28f6c1566d99cb18f5844b04aa19aeecf54->enter($__internal_ea081a83ac5573dcd9d655db3705c28f6c1566d99cb18f5844b04aa19aeecf54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Register</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 6, $this->getSourceContext()); })()), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 7, $this->getSourceContext()); })()), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 9, $this->getSourceContext()); })()), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_index");
        echo "\">List users</a>
        </li>
    </ul>
";
        
        $__internal_ea081a83ac5573dcd9d655db3705c28f6c1566d99cb18f5844b04aa19aeecf54->leave($__internal_ea081a83ac5573dcd9d655db3705c28f6c1566d99cb18f5844b04aa19aeecf54_prof);

        
        $__internal_fd161cd090e82ec9c35a81a7f04d3b2a9cf4ed148c6aeb9385e89b34f3a4124f->leave($__internal_fd161cd090e82ec9c35a81a7f04d3b2a9cf4ed148c6aeb9385e89b34f3a4124f_prof);

    }

    public function getTemplateName()
    {
        return "user/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Register</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('user_index') }}\">List users</a>
        </li>
    </ul>
{% endblock %}
", "user/new.html.twig", "/Users/daniellavalverde/Google Drive/Rendu/Symfony_Jour_03/ex_04/coding_academy/app/Resources/views/user/new.html.twig");
    }
}
